#include "GasWell.h"

GasWell::GasWell()
{
}

GasWell::GasWell(const string& name)
{
    this->wellName = name;
}

void GasWell::addWellData(const WellData& data)
{
    WellInfo.push_back(data);
}

const vector<WellData>& GasWell::getWellData() const
{
    return WellInfo;
}


int GasWell::partition(vector<GasWell>& wells, int low, int high)
{
    const GasWell& pivot = wells[high];
    int i = low - 1;

    for (int j = low; j < high; ++j) {
        if (compareByFlowToTemp(wells[j], pivot)) {
            ++i;
            swap(wells[i], wells[j]);
        }
    }
    swap(wells[i + 1], wells[high]);
    return i + 1;
};

void GasWell::quicksortFlowToTemp(vector<GasWell>& wells, int low, int high)
{
    stack<pair<int, int>> stack;
    stack.push(make_pair(low, high));

    while (!stack.empty()) {
        int start = stack.top().first;
        int end = stack.top().second;
        stack.pop();

        if (start < end) {
            int pivot = partition(wells, start, end);

            // Push subarrays to the stack
            stack.push(make_pair(start, pivot - 1));
            stack.push(make_pair(pivot + 1, end));
        }
    }
}

void GasWell::printSortedWells(const vector<GasWell>& wells)
{
    for (const auto& well : wells) {
        int sumFlow = 0;
        for (const auto& dailyData : well.WellInfo) {
            sumFlow += dailyData.flow;
            
        }
        double averageFlow = sumFlow / static_cast<double>(well.WellInfo.size());
        
        cout << "Average Flow Rate: " << (averageFlow) << endl;
    }
}

bool compareByFlowToTemp(const GasWell& a, const GasWell& b)
{
    int sumFlowA = 0, sumFlowB = 0;
    for (const auto& dailyData : a.WellInfo) {
        sumFlowA += dailyData.flow;
        
    }
    for (const auto& dailyData : b.WellInfo) {
        sumFlowB += dailyData.flow;
        
    }
    double averageFlowA = sumFlowA / static_cast<double>(a.WellInfo.size());
    double averageFlowB = sumFlowB / static_cast<double>(b.WellInfo.size());

    return (averageFlowA < averageFlowB);

}
